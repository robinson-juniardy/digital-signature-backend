const { database } = require("../../application/application");
const Controller = require("express").Router();
const Model = require("./suratmasuk.model");
const multer = require("multer");
const { filefilter, storage } = require("../../application/uploadFileSettings");
const upload = multer({ storage: storage, filefilter: filefilter });

Controller.get("/", async (request, response) => {
  let sql = "";
  if (request.query.history === true) {
    sql = `SELECT sm.*, disposisi.*, us.nama, role.role_name, approve_users.nama as user_approve, 
       approve_role.role_name as role_approve, (SELECT nama FROM users WHERE id=disposisi.disposisi_by) AS disposisi_by_name,
       (SELECT role_name FROM role LEFT JOIN users ON users.jabatan = role.id WHERE users.id=disposisi.disposisi_by) AS disposisi_by_role
       FROM surat_masuk sm
       LEFT JOIN disposisi on disposisi.id_surat = sm.id
       LEFT JOIN users us on us.id = disposisi.disposisi_user
       LEFT JOIN role on role.id = us.jabatan
       LEFT JOIN users approve_users on approve_users.id = disposisi.approve_by
       LEFT JOIN role approve_role on approve_role.id = approve_users.jabatan
       ORDER BY sm.id DESC`;
  } else {
    sql = `SELECT sm.*, disposisi.*, us.nama, role.role_name, approve_users.nama as user_approve, 
       approve_role.role_name as role_approve, (SELECT nama FROM users WHERE id=disposisi.disposisi_by) AS disposisi_by_name,
       (SELECT role_name FROM role LEFT JOIN users ON users.jabatan = role.id WHERE users.id=disposisi.disposisi_by) AS disposisi_by_role
       FROM surat_masuk sm
       LEFT JOIN disposisi on disposisi.id_surat = sm.id
       LEFT JOIN users us on us.id = disposisi.disposisi_user
       LEFT JOIN role on role.id = us.jabatan
       LEFT JOIN users approve_users on approve_users.id = disposisi.approve_by
       LEFT JOIN role approve_role on approve_role.id = approve_users.jabatan
       WHERE disposisi.disposisi_id IS NULL AND sm.status_dokumen < 2
       ORDER BY sm.id DESC`;
  }
  const result = await database
    .execute(sql)
    .then((response) => response)
    .catch((error) => error);
  response.json(result);
});

Controller.get("/disposisi-proses", async (request, response) => {
  const result = await database
    .execute(
      `
      SELECT * FROM surat_masuk sm INNER JOIN disposisi ds on ds.id_surat = sm.id WHERE sm.status_dokumen = 2 AND ds.status < ${request.query.disposision_level}
  `
    )
    .then((response) => response)
    .catch((error) => error);

  response.json(result);
});

Controller.get("/disposisi-selesai", async (request, response) => {
  const result = await database
    .execute(
      `
      SELECT * FROM surat_masuk sm INNER JOIN disposisi ds on ds.id_surat = sm.id WHERE sm.status_dokumen = 5 AND ds.status < ${request.query.disposision_level}
      `
    )
    .then((response) => response)
    .catch((error) => error);

  response.json(result);
});

Controller.post("/proses", async (request, response) => {
  console.log(request.body);
  const result = await database
    .execute(
      `
    UPDATE surat_masuk SET status_dokumen = ${request.body.status}, 
    modified_by='${request.body.created_by}',
    modified_time = '${new Date()}'
    WHERE id =${request.body.id_surat}
  `
    )
    .then((response) => response)
    .catch((error) => error);

  response.json(result);
});

Controller.post("/arsip", async (request, response) => {
  const result = await database
    .execute(
      `
    INSERT INTO arsip_surat (id_surat, jenis_arsip_surat, created_by)
    VALUES(${request.body.id_surat}, '${request.body.jenis_arsip}', '${request.body.created_by}')
  `
    )
    .then((response) => response)
    .catch((error) => error);

  response.json(result);
});

Controller.get("/arsip/:user_id", async (request, response) => {
  const result = await database
    .execute(
      `
    SELECT sm.*, arsip.created_time as tanggal_arsip FROM arsip_surat as arsip
    INNER JOIN surat_masuk sm on sm.id = arsip.id_surat
    WHERE arsip.created_by = '${request.params.user_id}'
  `
    )
    .then((response) => response)
    .catch((error) => error);

  response.json(result);
});

Controller.post("/approval", async (request, response) => {
  console.log(request.body);
  if (request.body.role === "ka_opd") {
    const result = await database
      .execute(
        `INSERT INTO disposisi (id_surat, status, approve, approve_by)
      VALUES(${request.body.idSurat}, ${request.body.status}, ${request.body.approve}, ${request.body.approveBy})
      `
      )
      .then((response) => response)
      .catch((error) => error);
    response.json(result);
  } else {
    const result = await database
      .execute(
        `UPDATE disposisi SET approve=${request.body.approve}, approve_by=${request.body.approveBy} WHERE id_surat=${request.body.idSurat}`
      )
      .then((response) => response)
      .catch((error) => error);
    response.json(result);
  }
});

Controller.get("/disposisi/:user_id", async (request, response) => {
  const result = await database
    .execute(
      `SELECT * FROM surat_masuk sm
        INNER JOIN disposisi ds ON ds.id_surat = sm.id
        INNER JOIN users us on us.id = ds.disposisi_by
        INNER JOIN role ON role.id = us.jabatan
        WHERE ds.disposisi_user = ${request.params.user_id}
        AND sm.status_dokumen < 5
        ORDER BY sm.jenis_surat DESC
        `
    )
    .then((response) => response)
    .catch((error) => error);
  response.json(result);
});

Controller.post("/disposisi", async (request, response) => {
  console.log(request.body);
  if (request.body.role === "ka_opd") {
    const result = await database
      .execute(
        `INSERT INTO disposisi (id_surat, disposisi_user, status, disposisi_by)
    VALUES(${request.body.idSurat}, ${request.body.disposisiUser}, ${request.body.status}, ${request.body.disposisiBy})`
      )
      .then((response) => response)
      .catch((error) => error);
    response.json(result);
  } else {
    const result = await database
      .execute(
        `UPDATE disposisi SET 
        disposisi_user=${request.body.disposisiUser}, 
        status=${request.body.status}, disposisi_by=${request.body.disposisiBy}
        WHERE id_surat=${request.body.idSurat}
        `
      )
      .then((response) => response)
      .catch((error) => error);
    response.json(result);
  }
});

Controller.post("/", upload.single("fileName"), async (request, response) => {
  const formData = {
    tanggalTerimaSurat: request.body.tanggalTerimaSurat,
    perihalSurat: request.body.perihalSurat,
    jenisSurat: request.body.jenisSurat,
    fileName: request.file.filename,
  };

  const result = await database
    .execute(Model.addSuratMasuk(formData))
    .then((response) => response)
    .catch((error) => error);

  response.json(result);
});

module.exports = Controller;
