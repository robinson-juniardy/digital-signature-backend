const { database } = require("../../application/application");
const Controller = require("express").Router();

Controller.get("/", async (request, response) => {
  const suratkeluar = await database
    .execute(`SELECT filename FROM surat_keluar_temp GROUP BY filename`)
    .then((response) => {
      return response;
    })
    .catch((error) => error);
  const suratmasuk = await database
    .execute(`SELECT filename FROM surat_masuk`)
    .then((response) => {
      return response;
    })
    .catch((error) => error);

  const disposisi_selesai = await database
    .execute(
      `SELECT id from surat_masuk
       LEFT JOIN disposisi ON disposisi.id_surat = surat_masuk.id WHERE disposisi_user is not null and approve is not null`
    )
    .then((response) => {
      return response;
    })
    .catch((error) => error);
  const disposisi_proses = await database
    .execute(
      `SELECT id from surat_masuk
       LEFT JOIN disposisi ON disposisi.id_surat = surat_masuk.id
       WHERE disposisi_user is not null and approve is null`
    )
    .then((response) => {
      return response;
    })
    .catch((error) => error);
  const tidak_disposisi = await database
    .execute(
      `SELECT id from surat_masuk
      LEFT JOIN disposisi ON disposisi.id_surat = surat_masuk.id
      WHERE disposisi_user is null and approve is not null`
    )
    .then((response) => {
      return response;
    })
    .catch((error) => error);
  const belum_diproses = await database
    .execute(
      `SELECT id from surat_masuk
      LEFT JOIN disposisi ON disposisi.id_surat = surat_masuk.id
      WHERE disposisi_user is null and approve is null`
    )
    .then((response) => {
      return response;
    })
    .catch((error) => error);

  response.json({
    suratmasuk: suratmasuk.data.length,
    suratkeluar: suratkeluar.data.length,
    disposisi_selesai: disposisi_selesai.data.length,
    disposisi_proses: disposisi_proses.data.length,
    tidak_disposisi: tidak_disposisi.data.length,
    belum_diproses: belum_diproses.data.length,
  });
});

module.exports = Controller;
