const { database } = require("../../application/application");
const Controller = require("express").Router();
const Model = require("./suratkeluar.model");
const multer = require("multer");
const { filefilter, storage } = require("../../application/uploadFileSettings");
const upload = multer({ storage: storage, filefilter: filefilter });

Controller.get("/", async (request, response) => {
  const result = await database
    .execute(Model.getSuratKeluar())
    .then((response) => response)
    .catch((error) => error);
  response.json(result);
});

Controller.get("/temp-byid/:id", async (request, response) => {
  const result1 = await database
    .execute(
      `SELECT * FROM statussigndokumen WHERE eksekutor=${request.params.id} GROUP BY filename `
    )
    .then((response) => {
      return response;
    })
    .catch((error) => error);

  const res = [];

  for (value of result1.data) {
    const detail = await database
      .execute(
        `SELECT statussigndokumen.*, role.role_name as status_jabatan FROM statussigndokumen
        LEFT JOIN role on role.id = statussigndokumen.jabatan
        WHERE filename = '${value.filename}'`
      )
      .then((response) => {
        res.push({
          ...value,
          detail: response.data,
        });
        return response;
      })
      .catch((error) => error);
  }

  response.json(res);
});

Controller.post("/hapus-suratkeluar", async (request, response) => {
  const result = await database
    .execute(
      `DELETE FROM document_sign WHERE filename='${request.body.filename}'`
    )
    .then((result) => result)
    .catch((error) => error);
  response.json(result);
});

Controller.post(
  "/revisi",
  upload.single("fileName"),
  async (request, response) => {
    console.log(request.body);
    const result = await database
      .execute(
        `UPDATE document_sign SET 
       status='${request.body.status}',
       status_eksekusi='${request.body.status_eksekusi}',
       status_level=${request.body.status_level},
       lastmodified_time='${new Date()}',
       alasan_revisi='${request.body.alasan_revisi}'
       WHERE filename='${request.body.old_filename}'`
      )
      .then((response) => response)
      .catch((error) => error);

    response.json(result);
  }
);

Controller.get("/temp", async (request, response) => {
  const result1 = await database
    .execute(`SELECT * FROM statussigndokumen GROUP BY filename`)
    .then((response) => {
      return response;
    })
    .catch((error) => error);

  const res = [];

  for (value of result1.data) {
    const detail = await database
      .execute(
        `SELECT statussigndokumen.*, role.role_name as status_jabatan FROM statussigndokumen
        LEFT JOIN role on role.id = statussigndokumen.jabatan
        WHERE filename = '${value.filename}'`
      )
      .then((response) => {
        res.push({
          ...value,
          detail: response.data,
        });
        return response;
      })
      .catch((error) => error);
  }

  response.json(res);
});

Controller.get("/temp-status-data", async (request, response) => {
  const result = await database
    .execute(
      `SELECT filename, perihal, judul, created_time, (CASE 
      WHEN status <1 THEN 'Dikirimkan' 
      WHEN status = 1 THEN 'Diproses' 
      WHEN status IS NULL THEN 'Selesai' END) AS status 
      from surat_keluar_temp GROUP BY filename;`
    )
    .then((response) => response)
    .catch((error) => error);
  response.json(result);
});

Controller.get("/signature", async (request, response) => {
  const result = await database
    .execute(
      `SELECT id, nama, jabatan, nip, role FROM users WHERE role NOT IN ('operator','admin') ORDER BY id DESC`
    )
    .then((response) => response)
    .catch((error) => error);
  response.json(result);
});

Controller.get("/sign-list/", async (request, response) => {
  const result = await database
    .execute(Model.getSignList(request.query))
    .then((response) => response)
    .catch((error) => error);
  response.json(result);
});

Controller.get("/status-sign-dokumen", async (request, response) => {
  const result = await database
    .execute("SELECT * FROM statussigndokumen")
    .then((response) => response)
    .catch((error) => error);
  response.json(result);
});

Controller.post("/", upload.single("fileName"), async (request, response) => {
  const formData = {
    judul: request.body.judul,
    perihal: request.body.perihalSurat,
    fileName: request.file.filename,
    annot: JSON.parse(request.body.annot),
  };

  const result = await database
    .execute(Model.addSuratKeluar(formData))
    .then((response) => response)
    .catch((error) => error);

  response.json(result);
});

Controller.post(
  "/sign",
  upload.single("fileName"),
  async (request, response) => {
    console.log(request.file);
    const result = await database
      .execute(
        `UPDATE document_sign SET 
       filename='${request.file.filename}',
       status='${request.body.status}',
       status_eksekusi='${request.body.status_eksekusi}',
       status_level=${
         request.body.status_level === 3 ? 3 : request.body.status_level
       },
       lastmodified_time='${new Date()}'
       WHERE filename='${request.body.old_filename}'`
      )
      .then((response) => response)
      .catch((error) => error);

    response.json(result);
  }
);

module.exports = Controller;
